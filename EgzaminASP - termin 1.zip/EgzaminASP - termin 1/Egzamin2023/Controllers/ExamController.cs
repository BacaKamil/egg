﻿using Egzamin2023.Models;
using Egzamin2023.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using static System.Runtime.InteropServices.JavaScript.JSType;

// Bartosz Książek 14297

namespace Egzamin2023.Controllers
{
    public class ExamController : Controller
    {
        public IDateProvider _idateprovide;
        public INoteService _note;

        public ExamController(IDateProvider idateprovide, INoteService note)
        {
            _idateprovide = idateprovide;
            _note = note;
        }

        public IActionResult Index()
        {
            return View(_note.GetAll());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Note model)
        {
            if (ModelState.IsValid)
            {
                if (model.Deadline < _idateprovide.CurrentDate)
                {
                    ModelState.AddModelError("Deadline", "Czas ważności musi być o godzinę późniejszy od bieżącego czasu!");
                }
                _note.Add(model);

                return RedirectToAction("Index");
            }

            return View();
        }

        
    }
}
