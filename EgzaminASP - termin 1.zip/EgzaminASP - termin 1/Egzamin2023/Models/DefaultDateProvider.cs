﻿using Egzamin2023.Services;
// Bartosz Książek 14297

namespace Egzamin2023.Models
{
    public class DefaultDateProvider : IDateProvider
    {
        public DateTime CurrentDate { get => DateTime.Now; }
    }
}
