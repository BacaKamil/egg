﻿using System.ComponentModel.DataAnnotations;
// Bartosz Książek 14297

namespace Egzamin2023.Models
{
    public class Note
    {
        [Display(Name = "Tytuł")]
        [MinLength(3)]
        [MaxLength(20)]
        public string Title { get; set; }
        [Display(Name = "Treść")]
        [MinLength(3)]
        [MaxLength(2000)]
        public string Content { get; set; }
        [Display(Name = "Data Ważności")]
        
        public DateTime Deadline { get; set; }
    }
}
