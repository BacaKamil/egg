namespace Egzamin2023.Models;
// Bartosz Ksi��ek 14297

public class ErrorViewModel
{
    public string? RequestId { get; set; }

    public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
}