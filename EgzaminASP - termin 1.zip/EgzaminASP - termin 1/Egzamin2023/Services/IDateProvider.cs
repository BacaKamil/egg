﻿namespace Egzamin2023.Services;
// Bartosz Książek 14297

public interface IDateProvider
{
    public DateTime CurrentDate { get; }
}